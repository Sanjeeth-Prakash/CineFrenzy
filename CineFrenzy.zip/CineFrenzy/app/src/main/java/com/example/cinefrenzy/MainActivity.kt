package com.example.cinefrenzy

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.cinefrenzy.databinding.ActivityMainBinding
import com.example.cinefrenzy.viewmodel.MovieViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MovieViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Use the actual API key from BuildConfig
        viewModel.fetchPopularMovies(BuildConfig.TMDB_API_KEY)

        // Observe movie data using lifecycleScope
        lifecycleScope.launch {
            viewModel.movies.collectLatest { movies ->
                binding.recyclerView.adapter = MovieAdapter(movies)
            }
        }
    }
}
