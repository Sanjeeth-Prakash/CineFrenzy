package com.example.cinefrenzy.model

data class MovieResponse(

    val results: List<Movie>
)
