package com.example.cinefrenzy.repository

import com.example.cinefrenzy.network.ApiService
import com.example.cinefrenzy.model.MovieResponse

class MovieRepository(private val apiService: ApiService) {

    suspend fun getPopularMovies(apiKey: String): MovieResponse {
        return apiService.getPopularMovies(apiKey)
    }

    suspend fun searchMovies(apiKey: String, query: String): MovieResponse {
        return apiService.searchMovies(apiKey, query)
    }
}
